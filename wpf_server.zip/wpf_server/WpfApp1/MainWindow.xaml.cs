﻿using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private TcpClient _client;
        private string _myId;

        // 생성자를 수정하여 연결된 정보를 받습니다.
        public MainWindow(TcpClient connectedClient, string userId)
        {
            InitializeComponent();

            this._client = connectedClient;
            this._myId = userId;

            // C++ 엔진 초기화 및 수신 스레드 시작
            StartGameLogic();
        }
        private void StartGameLogic()
        {
            // 1. C++ 엔진 init_engine() 호출
            // 2. 수신 스레드(ReceiveLoop) 시작
            // 3. 엔진 타이머 가동
        }

        private void BtnConnect_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}